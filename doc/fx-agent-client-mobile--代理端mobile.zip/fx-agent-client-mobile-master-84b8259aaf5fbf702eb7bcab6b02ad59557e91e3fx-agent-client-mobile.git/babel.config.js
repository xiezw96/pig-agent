module.exports = {
  presets: ['@vue/app'],
  plugins: ['lodash'],
};
