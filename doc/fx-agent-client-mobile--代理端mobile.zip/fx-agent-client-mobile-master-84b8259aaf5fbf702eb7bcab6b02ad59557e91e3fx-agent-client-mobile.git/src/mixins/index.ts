export { default as AddressAddForm } from './address-add';
export { default as AddressFormConfig } from './address-form';
export { default as DateSegment } from './date-segment';
export { default as GoodsSearch } from './goods-search';
export { default as ValidateCode } from './validate-code';
export { default as WxPay } from './wx-pay';
