export * from './app.plugin';
import './f2';
