export interface ToastEntity {
  txt: string;
  type?: string;
  time?: number;
  mask?: boolean;
  maskClosable?: boolean;
  $events?: any;
}
