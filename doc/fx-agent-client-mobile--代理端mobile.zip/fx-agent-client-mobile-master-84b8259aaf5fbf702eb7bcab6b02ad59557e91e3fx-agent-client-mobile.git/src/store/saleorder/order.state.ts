export interface OrderState {
  list: any[];
  isMore: boolean;
}
