export class EquipmentState {
  equipments: any[] = [];
}
