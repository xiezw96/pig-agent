export interface SettlementState {
  list: any[];
  commission: number;
  settlementPrice: number;
  originalSettlementPrice: number;
  isMore: boolean;
}
