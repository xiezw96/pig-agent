export * from './root.state';
export * from './root.store';

export { buildStore, rootStore as store } from './root.store';
