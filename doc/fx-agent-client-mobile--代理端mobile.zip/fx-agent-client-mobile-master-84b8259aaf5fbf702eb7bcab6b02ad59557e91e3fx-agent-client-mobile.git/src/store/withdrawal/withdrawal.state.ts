export interface WithdrawalState {
  list: any[];
  withdrawalTotal: string;
}
