import { UserState } from './user.state';

export interface AccountState {
  user: UserState;
}
