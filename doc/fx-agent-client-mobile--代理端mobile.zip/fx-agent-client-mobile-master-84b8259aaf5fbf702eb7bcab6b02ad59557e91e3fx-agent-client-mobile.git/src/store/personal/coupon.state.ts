export interface CouponState {
  list: any[];
}
