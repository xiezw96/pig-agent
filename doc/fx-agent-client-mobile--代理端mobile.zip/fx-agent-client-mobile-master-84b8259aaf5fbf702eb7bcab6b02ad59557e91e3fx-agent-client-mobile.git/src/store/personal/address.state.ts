export interface AddressState {
  list: any[];
}
