export class UserEntity {
  id: number;
  name: string;
  auditStatus: number;
}
