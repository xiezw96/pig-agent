export class GoodsGroupEntity {
  id: number;

  /**
   * 名称
   */
  name: string;

  /**
   * 序号
   */
  sort: number;

  /**
   * 操作人
   */
  operator: number;

  /**
   * 操作时间
   */
  updateTime: number;
}
