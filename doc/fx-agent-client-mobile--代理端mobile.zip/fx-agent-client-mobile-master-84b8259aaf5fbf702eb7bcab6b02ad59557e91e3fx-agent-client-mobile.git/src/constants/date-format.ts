export const DATE = 'YYYY-MM-DD';
export const POPULAR_DATETIME = 'YYYY-MM-DD HH:mm:ss';
