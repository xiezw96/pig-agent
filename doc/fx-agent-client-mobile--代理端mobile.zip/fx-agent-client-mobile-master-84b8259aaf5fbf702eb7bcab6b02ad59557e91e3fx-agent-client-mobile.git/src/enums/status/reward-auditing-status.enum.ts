export enum RewardAuditedStatus {
  待审核,
  通过,
  未通过,
}
