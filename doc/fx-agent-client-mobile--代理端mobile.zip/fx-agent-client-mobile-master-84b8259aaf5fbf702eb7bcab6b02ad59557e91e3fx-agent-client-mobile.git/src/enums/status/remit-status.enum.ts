export enum RemitStatus {
  待打款,
  已打款,
}
