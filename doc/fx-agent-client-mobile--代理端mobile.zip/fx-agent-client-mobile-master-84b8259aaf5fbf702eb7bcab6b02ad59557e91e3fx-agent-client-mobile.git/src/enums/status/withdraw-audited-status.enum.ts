export enum WithdrawAuditedStatus {
  待处理,
  通过,
  拒绝,
  已打款,
}
