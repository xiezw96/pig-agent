export enum BoxStatus {
  正常 = 1,
  故障,
  补货,
  出货,
}
