export enum AnnouncementStatus {
  关闭,
  开启,
}
