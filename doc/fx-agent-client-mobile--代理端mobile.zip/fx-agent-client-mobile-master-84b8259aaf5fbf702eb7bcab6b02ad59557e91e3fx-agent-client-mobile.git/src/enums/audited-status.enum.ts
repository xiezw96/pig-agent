export enum AuditedStatus {
  待审核,
  通过,
  不通过,
}
