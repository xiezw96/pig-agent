export enum SourceStatus {
  自有,
  商城,
  下级,
}
