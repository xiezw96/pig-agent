export enum SourcePay {
  ACTIVE = 0,
  SHOPPINGMALL = 1,
  CLIENT = 2,
}
