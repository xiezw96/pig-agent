export enum ActiveStatus {
  正常,
  待激活,
  冻结,
}
