export enum DeviceStatus {
  待激活,
  正常,
  故障,
  补货,
  出货,
  离线,
  回收,
}
