export enum OrderOfAgent {
  // 自有、商城（线上商城消费）、下级
  OWN = 0,
  SHOPPINGMALL = 1,
  SUBORDINATE = 2,
}
