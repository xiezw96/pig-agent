export enum LogisticsStatus {
  已发货,
  未发货,
}
