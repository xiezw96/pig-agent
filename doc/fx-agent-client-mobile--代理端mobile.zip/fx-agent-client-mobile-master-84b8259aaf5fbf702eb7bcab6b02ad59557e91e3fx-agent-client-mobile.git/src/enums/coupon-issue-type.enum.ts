export enum CouponIssuanceType {
  自动发放,
  手动发放,
}
