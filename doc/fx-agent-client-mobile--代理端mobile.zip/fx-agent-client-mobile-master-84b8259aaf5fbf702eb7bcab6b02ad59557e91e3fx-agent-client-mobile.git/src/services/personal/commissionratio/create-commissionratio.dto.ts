export interface CreateCommissionratioDto {
  id?: number;
  ratio: number;
}
