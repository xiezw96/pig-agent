export interface CreateAddressDto {
  id?: number;
  name: string;
  phone: string;
  privince: string;
  city: string;
  area: string;
  address: string;
  isDefault: number;
}
