export interface GetLevelsDto {
  name?: string;
}
