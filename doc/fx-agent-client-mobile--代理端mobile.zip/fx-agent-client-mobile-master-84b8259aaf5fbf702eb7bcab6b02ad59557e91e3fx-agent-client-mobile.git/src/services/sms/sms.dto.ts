export interface SmsDto {
  code?: string;
  phone: string;
  type: string;
}
