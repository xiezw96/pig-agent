export interface FindUsersDto {
  name?: string;
}
