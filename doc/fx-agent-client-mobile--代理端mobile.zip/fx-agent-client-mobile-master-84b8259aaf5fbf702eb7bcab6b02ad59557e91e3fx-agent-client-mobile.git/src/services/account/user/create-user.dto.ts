export interface CreateUserDto {
  accountName: string;

  name: string;

  password: string;

  roleId: number;
}
