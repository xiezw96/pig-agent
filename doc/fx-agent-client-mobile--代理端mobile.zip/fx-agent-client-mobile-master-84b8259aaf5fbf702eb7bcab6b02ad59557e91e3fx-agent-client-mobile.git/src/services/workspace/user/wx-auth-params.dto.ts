export interface WxAuthParamsDto {
  code: string;
  state: string;
}
