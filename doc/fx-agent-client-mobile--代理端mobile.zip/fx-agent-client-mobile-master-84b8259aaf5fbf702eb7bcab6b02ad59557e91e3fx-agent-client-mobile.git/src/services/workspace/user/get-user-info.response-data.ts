export interface GetUserInfoResponseData {
  sysUser: any;
  roles: any[];
  permissions: any[];
}
