export interface FindCategoriesDto {
  name?: string;
}
