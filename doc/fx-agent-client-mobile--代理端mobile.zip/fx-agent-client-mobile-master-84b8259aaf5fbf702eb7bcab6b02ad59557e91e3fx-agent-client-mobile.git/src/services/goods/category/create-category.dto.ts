export interface CreateCategoryDto {
  name: string;

  sort: number;
}
