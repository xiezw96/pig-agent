export interface CreateGroupDto {
  name: string;

  sort: number;
}
