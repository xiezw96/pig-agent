export interface FindGroupsDto {
  name?: string;
}
