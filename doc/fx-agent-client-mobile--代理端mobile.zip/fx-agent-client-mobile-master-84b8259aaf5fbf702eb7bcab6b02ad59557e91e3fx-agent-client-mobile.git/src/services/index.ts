export * from './workspace';
export * from './personal';
export * from './sms';
export * from './account';
/**
 * 优惠券
 */
export * from './coupon';
/**
 * 我的柜子
 */
export * from './salesmachine';
export * from './combo';
export * from './saleorder';
export * from './settlement';
export * from './withdrawal';
export * from './notice-message';

export * from './auditing';
export * from './customer';
export * from './goods';
// export * from './report';
export * from './setting';

export * from './mall.service';
export * from './report.service';

// 柜子相关
export * from './equipment.service';

// 模板管理
export * from './template';
