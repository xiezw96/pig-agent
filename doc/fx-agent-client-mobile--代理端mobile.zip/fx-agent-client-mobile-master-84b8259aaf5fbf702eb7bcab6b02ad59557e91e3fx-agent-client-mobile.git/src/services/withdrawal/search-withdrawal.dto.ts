export interface SearchWithdrawal {
  reqStartTime?: string;
  reqEndTime?: string;
  source?: number;
}
