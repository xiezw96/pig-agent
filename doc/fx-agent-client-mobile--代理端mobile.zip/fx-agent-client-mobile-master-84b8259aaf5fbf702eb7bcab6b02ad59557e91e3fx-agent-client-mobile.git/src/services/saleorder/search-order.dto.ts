export interface SearchOrder {
  orderCreateStartTime?: string;
  orderCreateEndTime?: string;
  source?: number;
  orderCode?: string;
  current: number;
  size: number;
}
