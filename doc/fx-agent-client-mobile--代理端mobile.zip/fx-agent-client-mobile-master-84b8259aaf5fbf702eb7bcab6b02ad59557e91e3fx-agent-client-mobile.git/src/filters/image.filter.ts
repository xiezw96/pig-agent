export function image(id: string) {
  return `api/admin/file/${id}`;
}
