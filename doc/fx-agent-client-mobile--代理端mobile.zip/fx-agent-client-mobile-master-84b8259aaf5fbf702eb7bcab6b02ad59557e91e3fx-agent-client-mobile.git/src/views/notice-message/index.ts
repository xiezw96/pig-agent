export { default as NoticeMessage } from './notice-message.vue';
