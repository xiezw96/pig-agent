export { default as Home } from './home.vue';
export { default as Login } from './login.vue';
export { default as Register } from './register.vue';
export { default as ResetPwd } from './reset-pwd.vue';
