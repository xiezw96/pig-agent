export { default as Equipment } from './equipment.vue';
