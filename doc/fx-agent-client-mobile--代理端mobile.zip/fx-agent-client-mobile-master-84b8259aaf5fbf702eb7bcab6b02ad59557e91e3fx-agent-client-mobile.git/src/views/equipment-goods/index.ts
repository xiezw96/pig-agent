export { default as EquipmentGoods } from './equipment-goods.vue';
