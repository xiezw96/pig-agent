export { default as ProcurementMall } from './procurement-mall.vue';
export { default as ProcurementMallDetail } from './detail.vue';
export { default as ProcurementMallPay } from './check-pay.vue';
export { default as ProcurementMallOrder } from './purchase-order.vue';
export { default as ProcurementMallRecord } from './purchase-record.vue';
export { default as ProcurementMallSearch } from './search.vue';
